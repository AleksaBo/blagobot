# изучение работы с модулем json а то забыл

#
import re
import json
 
dict_d={}

def di2jsn(dictt):
    
    jsn_data = json.dumps(dictt, ensure_ascii=False, 
                          sort_keys=True, indent=4)

    return jsn_data

def sv_jsn(path, jsn_d):
    with open(path, "w")as fiw:
        fiw.write(jsn_d)
        
    return f"Ok, {jsn_d}, write in {path} !!!"    


def jsn2diobj(path):
    with open(path, "r") as fr:
        di = fr.read()
    return di


def rd_fibiblvers(path):
    with open(path, "r") as fr:
        strii = fr.read()
    return strii


def txt2dival(txtt):
    """
        создание элементов словаря 1(день):{заголовок1:[txtt, ссылка]}
        txtt - текст выбранных стихов с указанием места в соответствии с
        сайтом bible....
        return пока строка, но нужно переделать в картеж
    """

     # читаем файл txt
    li = rd_fibiblvers('/home/sabo/Progy/bmpgo/didl_ves.txt')

    # извлекаем техт без номеров стихов
    lii = re.sub('[0-9]?', '', li)

    # извлекаем техт без ссылок вида " [21] "
    linn=re.sub('\[\d*\]','', lii)
    # создаем список из строк без номеров стихов"
    liii = re.split('\n',linn)
    # поиск книги и номера главы
    li = linn=re.sub('\[\d*\]','', li)
    lib = re.findall("\s\s\d? ?[А-я|a-z]+", li)
    # вяртае спiс трэба выдзелiць першы и адзiны элемент
    # а з яго ужо выбравць страку без першых дзьвух сымбаляу
    book = lib[0][2:]
    # поиск номеров стихов (первого[min] и последнего[max])
    listr = re.findall('\d{1,2}', li)    
    lili=[int(i) for i in listr]      
    liab=lili[:-3] 
    liab.sort()
    a,b=min(liab),max(liab)   
    stihi=f'{book} {a}:{b}'
    return stihi


def run_dict_bild(n_day_strt, n_day_end, lst_headrs):
    """ 
    n_day_list - число дней (определяет кол-во итераций цикла запросов создания словаря)
    lst_headrsи - список заголовков тем ежедневных размышлений
    
    return - dictionary вида     dic7day={day:{
                                          header1:[text1, biblr_ref1]
                                          header2:[text2, biblr_ref1]
                                          header3:[text3, biblr_ref1]
                                          .......
                                          }
                                        }
    """
    global dict_d
    print([f"{key}-{key_val} " for key, key_val in dict_d.items()])
    
    dict_hh={}
    
    for d in range(n_day_strt,n_day_end+1):
        for hh in lst_headrs:
            
            wh=True
            list_text_plus_ref=[]
            bt=1
            
            while wh:

                list_text_plus_ref.append((input(f"день {d} _ {hh} _ {bt} - text \n"), input('книга')))
                if input(f'продолжим и введем отрывок {bt+1} ? "Enter"-exit ') == '':
                    wh=False
                else: bt+=1
            dict_hh[f"{hh}"] = list_text_plus_ref
        dict_d[f"{d}"] = dict_hh

        

    


def main():
    list_tem=['Поклонение', 'Признание', 'Обновление', 'Личные просьбы', 'Ходотайство', 'Благодарение', 'Заключение']
    #list_tem=['Поклонение', 'Признание']

    dict_d = jsn2diobj('123.jn')
  

    sss=run_dict_bild(1, 1, list_tem)

    sv_jsn('123.jn', sss)

    print(sss)




if __name__ == "__main__":

    main()

    pass
    
